export function applyLayoutsDefaults(defaults: any): void;
